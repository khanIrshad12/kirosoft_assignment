'use client';

import { motion } from 'framer-motion';
import { IoIosArrowDown } from "react-icons/io";
import { useState, useEffect } from 'react';

export default function Navbar() {
    const [showLetters, setShowLetters] = useState(false);
    const letters = ['G', 'C', 'O', 'R', 'E'];

    // Framer Motion Variants for Staggered Animation
    const staggerContainer = {
        hidden: { opacity: 0 },
        show: {
            opacity: 1,
            transition: {
                duration: 7,
                staggerChildren: 0.15,
            },
        },
    };

    const staggerItem = {
        hidden: { opacity: 0, y: 20 },
        show: { opacity: 1, y: 0 },
    };

    useEffect(() => {
        const timer = setTimeout(() => {
            setShowLetters(true);
        }, 500); // Start slightly after navbar appears

        return () => clearTimeout(timer);
    }, []);

    return (
        <motion.nav
            initial={{ y: -500, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 1, delay: 0.6, ease: "easeOut" }}
            className="fixed top-0 left-0 right-0 z-50 bg-[#151517]/80 backdrop-blur-sm"
        >
            <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
                {/* Left: Animated Logo */}
                <div className="flex items-center">
                    <div className="relative flex items-center">
                        <motion.div
                            initial={{ scale: 0, x: 0 }}
                            animate={{
                                scale: 1,
                                x: showLetters ? -6 : 0,
                            }}
                            transition={{
                                scale: { duration: 1.7, ease: "easeOut" },
                                x: { duration: 1, delay: 0.1, ease: "easeInOut" },
                            }}
                            className="w-8 h-8 bg-white rounded-full relative flex items-center justify-center"
                        >
                            <motion.div
                                initial={{ scale: 0 }}
                                animate={{ scale: 1, x: showLetters ? -7 : 0 }}
                                transition={{ duration: 2, delay: 0.1, ease: "easeOut" }}
                                className="text-[#151517] font-bold text-4xl"
                            >
                                G
                            </motion.div>
                        </motion.div>

                        <div className="flex h-8 items-center">
                            {letters.map((letter, index) => (
                                <motion.div
                                    key={letter}
                                    initial={{ opacity: 0, x: 10 }}
                                    animate={showLetters ? { opacity: 1, x: 0 } : {}}
                                    transition={{
                                        duration: 2,
                                        delay: 0.15 * (index + 1),
                                        ease: "easeOut",
                                    }}
                                    className="text-white font-bold text-lg"
                                >
                                    {letter}
                                </motion.div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Middle: Staggered Animation */}
                <motion.div
                    className="hidden md:flex space-x-6 text-[.9rem]"
                    initial="hidden"
                    animate="show"
                >
                    {["Products", "Pricing", "Resources", "Partners", "Why GCore"].map(
                        (item, index) => (
                            <motion.button
                                key={index}
                                className="text-gray-300 hover:text-white transition-colors flex items-center gap-1"
                                variants={staggerItem}
                            >
                                {item}
                                <IoIosArrowDown />
                            </motion.button>
                        )
                    )}
                </motion.div>

                {/* Right: Contact and Sign-up Buttons */}
                <div className="flex items-center space-x-4">
                    <button className="text-white isolate px-3 py-2 rounded-full bg-white/20 shadow-lg">
                        Contact us
                    </button>
                    <button className="px-4 py-2 bg-orange-500 text-white rounded-full hover:bg-orange-600 transition-colors">
                        Sign up for free
                    </button>
                </div>
            </div>
        </motion.nav>
    );
}
